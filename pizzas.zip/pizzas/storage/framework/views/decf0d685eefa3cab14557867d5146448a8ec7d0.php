<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Order now</div>

                    <div class="card-body">
                        <?php if(Auth::check()): ?>
                            <form action="<?php echo e(route('order.store')); ?>" method="post"><?php echo csrf_field(); ?>
                                <div class="form-group ">
                                    <p>Name:<?php echo e(auth()->user()->name); ?></p>
                                    <p>Email:<?php echo e(auth()->user()->email); ?></p>
                                    <p>Phone number: <input type="number" class="form-control" name="phone" required></p>
                                    <p>Small pizza order: <input type="number" class="form-control" name="small_pizza"
                                            value="0"></p>
                                    <p>Medium pizza order: <input type="number" class="form-control" name="medium_pizza"
                                            value="0"></p>
                                    <p>Large pizza order: <input type="number" class="form-control" name="large_pizza"
                                            value="0"></p>
                                    <p><input type="hidden" name="pizza_id" value="<?php echo e($pizza->id); ?>"></p>
                                    <p>Date:<input type="date" name="date" class="form-control" required></p>
                                    <p>Time:<input type="time" name="time" class="form-control" required></p>
                                    <p>Message:<textarea class="form-control" name="body" required></textarea></p>

                                    <p class="text-center">

                                        <button class="btn btn-danger" type="submit">Make order</button>
                                    </p>
                                    <?php if(session('message')): ?>
                                        <div class="alert alert-success" role="alert">
                                            <?php echo e(session('message')); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if(session('errmessage')): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e(session('errmessage')); ?>

                                    </div>
                                <?php endif; ?>

                                </div>
                            </form>


                        <?php else: ?>
                            <p><a href="/login">Please login to make order</a></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Pizza</div>

                    <div class="card-body">


                        <img src="<?php echo e(Storage::url($pizza->image)); ?>" class="img-thumbnail" style="width: 100%;">
                        <p>
                        <h3><?php echo e($pizza->name); ?></h3>
                        </p>
                        <p>
                        <h3><?php echo e($pizza->description); ?>em Ipsum is simply dummy text of the printing </h3>
                        </p>
                        <p class="badge badge-success">Vegetarian</p>
                        <p class="lead">Small pizza price:$<?php echo e($pizza->small_pizza_price); ?></p>
                        <p class="lead">Medium pizza price:$<?php echo e($pizza->medium_pizza_price); ?></p>
                        <p class="lead">Large pizza price:$<?php echo e($pizza->large_pizza_price); ?></p>



                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        a.list-group-item {
            font-size: 18px;
        }

        a.list-group-item:hover {
            background-color: red;
            color: #fff;
        }

        .card-header {
            background-color: red;
            color: #fff;
            font-size: 20px;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/pizzas/resources/views/show.blade.php ENDPATH**/ ?>