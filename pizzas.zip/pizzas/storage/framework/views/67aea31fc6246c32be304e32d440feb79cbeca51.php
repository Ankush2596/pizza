<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-2">
                <div class="card">
                    <div class="card-header">Menu</div>
                    <div class="card-body">
                        <ul class="list-group">
                        <a href="<?php echo e(route('pizza.index')); ?>" class="list-group-item list-group-item-action">View</a>
                        <a href="<?php echo e(route('pizza.create')); ?>" class="list-group-item list-group-item-action">Create</a>
                        <a href="<?php echo e(route('user.order')); ?>" class="list-group-item list-group-item-action">User order</a>
  
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">All Pizza
                        <a href="<?php echo e(route('pizza.create')); ?>">
                            <button class="btn btn-success" style="float: right">Add pizza</button>
                        </a>
                    </div>

                    <div class="card-body">
                        <?php if(session('message')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">S.price</th>
                                    <th scope="col">M.price</th>
                                    <th scope="col">L.price</th>
                                    <th scope="col"></th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($pizzas) > 0): ?>
                                    <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($key + 1); ?></th>
                                            <td><img src="<?php echo e(Storage::url($pizza->image)); ?>" width="80"></td>
                                            <td><?php echo e($pizza->name); ?></td>
                                            <td><?php echo e($pizza->description); ?></td>
                                            <td><?php echo e($pizza->category); ?></td>
                                            <td><?php echo e($pizza->small_pizza_price); ?></td>
                                            <td><?php echo e($pizza->medium_pizza_price); ?></td>
                                            <td><?php echo e($pizza->large_pizza_price); ?></td>
                                            <td><a href="<?php echo e(route('pizza.edit', $pizza->id)); ?>"><button
                                                        class="btn btn-primary">Edit</button></a></td>
                                            <td><button class="btn btn-danger" data-toggle="modal"
                                                    data-target="#exampleModal<?php echo e($pizza->id); ?>">Delete</button></td>
                                            <!-- Modal -->
                                            <div class="modal fade" id="exampleModal<?php echo e($pizza->id); ?>" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <form action="<?php echo e(route('pizza.destroy', $pizza->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Delete
                                                                    confirmation</h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure ?
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-danger">Delete
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>
                                    <p>No pizza to show</p>
                                <?php endif; ?>


                            </tbody>
                        </table>
                        <?php echo e($pizzas->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/pizzas/resources/views/pizza/index.blade.php ENDPATH**/ ?>