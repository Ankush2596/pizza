<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">

            <div class="col-md-8">
                <?php if(count($errors) > 0): ?>
                <div class="card mt-5">
                    <div class="card-body">
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <p> <?php echo e($error); ?><p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">Edit Pizza</div>
                    <form action="<?php echo e(route('pizza.update',$pizza->id)); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                       <?php echo method_field('PUT'); ?>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="name">Name of pizzza</label>
                                <input type="text" class="form-control" name="name" placeholder="name of pizza"
                                    value="<?php echo e($pizza->name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="description">Description of pizzza</label>
                                <textarea class="form-control" name="description"><?php echo e($pizza->description); ?></textarea>
                            </div>
                            <div class="form-inline">
                                <label>Pizza price($)</label>
                                <input type="text" name="small_pizza_price" class="form-control"
                                    placeholder="small pizza price" value="<?php echo e($pizza->small_pizza_price); ?>">
                                <input type="text" name="medium_pizza_price" class="form-control"
                                    placeholder="medium pizza price" value="<?php echo e($pizza->medium_pizza_price); ?>">
                                <input type="text" name="large_pizza_price" class="form-control"
                                    placeholder="large pizza price" value="<?php echo e($pizza->large_pizza_price); ?>">

                            </div>
                            <div class="form-group">
                                <label for="description">Category</label>
                                <select class="form-control" name="category">
                                    <option value=""></option>
                                    <option value="vegetarian">Vegetarian Pizza</option>
                                    <option value="nonvegetarian">Non vegetarian Pizza</option>
                                    <option value="traditional">Traditional Pizza</option>

                                </select>
                            </div>
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" name="image" class="form-control" name="image">
                                <img src="<?php echo e(Storage::url($pizza->image)); ?>" width="80">
                            </div>
                            <div class="form-group text-center">
                                <button class="btn btn-primary" type="submit">Save</button>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/pizzas/resources/views/pizza/edit.blade.php ENDPATH**/ ?>