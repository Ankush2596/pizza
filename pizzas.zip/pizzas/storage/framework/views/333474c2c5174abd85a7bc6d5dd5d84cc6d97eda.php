<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">Menu</div>

                    <div class="card-body">
                      
                        <form action="<?php echo e(route('frontpage')); ?>" method="get">
                            <a class="list-group-item list-group-item-action" href="/">Back</a>
                            <input type="submit" value="Vegetarian" name="category" class="list-group-item list-group-item-action">
                            <input type="submit" value="Nonvegetarian" name="category" class="list-group-item list-group-item-action">
                            <input type="submit" value="Traditional" name="category" class="list-group-item list-group-item-action">
                            <input type="submit" value="Peri peri chicken" name="category" class="list-group-item list-group-item-action">
                            <input type="submit" value="Garlic PRAWN" name="category" class="list-group-item list-group-item-action">
                            <input type="submit" value="Chicken & Camembert" name="category" class="list-group-item list-group-item-action">
                            <input type="submit" value="Loaded pepperoni" name="category" class="list-group-item list-group-item-action">
                            <input type="submit" value="Spicy peppy paneer" name="category" class="list-group-item list-group-item-action">
                            <input type="submit" value="Spicy pepperoni" name="category" class="list-group-item list-group-item-action">
                            <input type="submit" value="Vegi pepperoni" name="category" class="list-group-item list-group-item-action">
                        </form>
                    
                       
                    </div>

                </div>
                  <div class="card card-body mt-3">
                  Hey guys, Please support me by giving 5 star.
                  if you want to learn Laravel by developing other real world projects then check out my other laravel course.
                  <a href="https://www.udemy.com/user/4f9778a0-ecef-4eac-84ce-bf0522c23e4a/" target="_blank">
                  See courses
                  </a>
                  If you need discount coupons please message on udemy
                  </div>
            </div>

            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Pizza(<?php echo e(count($pizzas)); ?> pizza)</div>

                    <div class="card-body">

                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-4 mt-2 text-center" style="border: 1px solid #ccc;">
                                    <img src="<?php echo e(Storage::url($pizza->image)); ?>" class="img-thumbnail" style="width: 100%;">
                                    <p><?php echo e($pizza->name); ?></p>
                                    <p><?php echo e($pizza->description); ?></p>
                                <a href="<?php echo e(route('pizza.show',$pizza->id)); ?>">
                                        <button class="btn btn-danger mb-1">Order Now</button>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>no pizzas to show</p>

                            <?php endif; ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
        a.list-group-item {
            font-size: 18px;
        }

        a.list-group-item:hover {
            background-color: red;
            color: #fff;
        }

        .card-header {
            background-color: red;
            color: #fff;
            font-size: 20px;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/pizzas/resources/views/frontpage.blade.php ENDPATH**/ ?>